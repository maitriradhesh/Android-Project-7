package com.example.homework7;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Context;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private List<Bookmark> bookmarkList = new ArrayList<>();
    private ArrayAdapter<Bookmark> adapter;
    private WebView webView;
    private EditText urlEditText;
    private List<String> bookmarks = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);
        urlEditText = findViewById(R.id.urlEditText);
        Button submitButton = findViewById(R.id.submitButton);
        Button bookmarkButton = findViewById(R.id.bookmarkButton);

        webView.getSettings().setJavaScriptEnabled(true);
        ListView bookmarksListView = findViewById(R.id.bookmarksListView);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, bookmarkList);
        bookmarksListView.setAdapter(adapter);

        bookmarksListView.setOnItemClickListener((parent, view, position, id) -> {
            Bookmark bookmark = bookmarkList.get(position);
            webView.loadUrl(bookmark.getUrl());
        });
        submitButton.setOnClickListener(v -> {
            String url = urlEditText.getText().toString();
            if (!url.startsWith("http://") && !url.startsWith("https://")) {
                url = "http://" + url;
            }
            webView.loadUrl(url);
        });

        bookmarkButton.setOnClickListener(v -> {
            String currentUrl = webView.getUrl();
            String title = webView.getTitle();
            addBookmark(title, currentUrl);
            Toast.makeText(MainActivity.this, "Bookmark added!", Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.context_menu, menu);
        for (int i = 0; i < bookmarks.size(); i++) {
            menu.add(0, i, 0, bookmarks.get(i));
        }
        return true;
    }
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        if (v == webView) {
            getMenuInflater().inflate(R.menu.context_menu, menu);
        }
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.copy_url) {
            // Copy current URL to clipboard. Implementation may vary based on API level.
            android.content.ClipboardManager clipboard = (android.content.ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            android.content.ClipData clip = android.content.ClipData.newPlainText("URL", webView.getUrl());
            clipboard.setPrimaryClip(clip);
            return true;
        }
        return super.onContextItemSelected(item);
    }

    public void addBookmark(String title, String url) {
        bookmarkList.add(new Bookmark(title, url));
        adapter.notifyDataSetChanged();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_bookmarks) {
            ListView bookmarksListView = findViewById(R.id.bookmarksListView);
            if (bookmarksListView.getVisibility() == View.GONE) {
                bookmarksListView.setVisibility(View.VISIBLE);
            } else {
                bookmarksListView.setVisibility(View.GONE);
            }
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }

    }
}